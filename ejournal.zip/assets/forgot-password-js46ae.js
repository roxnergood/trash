$( () => {
    window.initializeForgotPassword = n => {
        const t = document.querySelector("#selected_channel_type")
          , i = document.querySelector("#forgot_password_form_container")
          , r = document.querySelector("#forgot_password_modal");
        if (t) {
            if (t.onchange = () => {
                $.ajax({
                    type: "GET",
                    data: {
                        channelType: t.value,
                        platform: n.platform
                    },
                    url: "/Account/GetForgotPasswordTypeForm",
                    contentType: "application/json; charset=utf-8",
                    dataType: "html",
                    success: n => {
                        i && (i.innerHTML = n),
                        document.querySelector("#forgot_password_form") && ($(document.querySelector("#forgot_password_form")).removeData("validator").removeData("unobtrusiveValidation"),
                        $.validator.unobtrusive.parse("#forgot_password_form"))
                    }
                })
            }
            ,
            r)
                $("#forgot_password_modal").on("show.bs.modal", function() {
                    t.onchange()
                });
            else
                t.onchange();
            const u = document.querySelector("#forgot_password_alert");
            u && (u.parentElement.hidden = !0);
            window.onForgotPasswordAjaxRequestBegin = () => {
                u && (u.parentElement.hidden = !0,
                u.innerText = "");
                const n = document.querySelectorAll(".btn-primary");
                $(n).prop("disabled", !0)
            }
            ;
            window.onForgotPasswordAjaxRequestSuccess = n => {
                if (n.status !== !0) {
                    u.innerHTML = n.message;
                    u.parentElement.hidden = !1;
                    return
                }
                n.message && registerPopup({
                    contentTitle: n.statusText,
                    content: n.message
                });
                $(r).modal("hide");
                n.redirectUrl && (window.location.href = n.redirectUrl)
            }
        } else {
            const t = document.querySelector("#forgot_password_link");
            t ? (t.href = "#",
            delete t.dataset.target,
            delete t.dataset.toggle,
            t.onclick = () => {
                registerPopup({
                    content: n.translations.contactSupportToReset,
                    onClose: () => {
                        window.location.href = "/contact-us"
                    }
                })
            }
            ) : i && !r && registerPopup({
                content: n.translations.contactSupportToReset,
                onClose: () => {
                    window.location.href = "/contact-us"
                }
            })
        }
    }
}
);